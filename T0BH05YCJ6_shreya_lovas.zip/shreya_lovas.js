let notes = JSON.parse(localStorage.getItem("notes")) || [];
let editId = null;
const notesList = document.getElementById("notes-list");
const saveBtn = document.getElementById("save-note");
const titleInput = document.getElementById("note-title");
const contentInput = document.getElementById("note-content");
const tagsInput = document.getElementById("note-tags");
const searchBox = document.getElementById("search-box");
const themeToggle = document.getElementById("toggle-theme");

document.addEventListener("DOMContentLoaded", renderNotes);
saveBtn.addEventListener("click", handleSave);
searchBox.addEventListener("input", renderNotes);
themeToggle.addEventListener("click", () => {
    document.body.classList.toggle("dark");
});

function handleSave() {
    const title = titleInput.value.trim();
    const content = contentInput.value.trim();
    const tags = tagsInput.value.trim().split(',').map(t => t.trim()).filter(Boolean);

    if (!title || !content) return alert("Please fill in all fields.");

    const note = {
        id: editId || Date.now().toString(),
        title,
        content,
        tags,
        timestamp: new Date().toLocaleString(),
        pinned: false
    };

    if (editId) {
        notes = notes.map(n => n.id === editId ? note : n);
        editId = null;
    } else {
        notes.push(note);
    }

    localStorage.setItem("notes", JSON.stringify(notes));
    clearForm();
    renderNotes();
}

function renderNotes() {
    const query = searchBox.value.toLowerCase();
    let filtered = notes.filter(n =>
        n.title.toLowerCase().includes(query) ||
        n.content.toLowerCase().includes(query)
    );

    filtered.sort((a, b) => b.pinned - a.pinned);

    notesList.innerHTML = "";
    filtered.forEach(note => {
        const card = document.createElement("div");
        card.className = "note-card";
        card.innerHTML = `
      <div class="pin" onclick="togglePin('${note.id}')">📌</div>
      <h3>${note.title}</h3>
      <p>${note.content}</p>
      <p><strong>Tags:</strong> ${note.tags.join(', ')}</p>
      <div class="timestamp">${note.timestamp}</div>
      <button onclick="deleteNote('${note.id}')">🗑️</button>
      <button class="edit-btn" onclick="editNote('${note.id}')">✏️</button>
    `;
        notesList.appendChild(card);
    });
}

function deleteNote(id) {
    notes = notes.filter(n => n.id !== id);
    localStorage.setItem("notes", JSON.stringify(notes));
    renderNotes();
}

function editNote(id) {
    const note = notes.find(n => n.id === id);
    titleInput.value = note.title;
    contentInput.value = note.content;
    tagsInput.value = note.tags.join(', ');
    editId = id;
}

function togglePin(id) {
    notes = notes.map(n => n.id === id ? {
        ...n,
        pinned: !n.pinned
    } : n);
    localStorage.setItem("notes", JSON.stringify(notes));
    renderNotes();
}

function clearForm() {
    titleInput.value = "";
    contentInput.value = "";
    tagsInput.value = "";
}